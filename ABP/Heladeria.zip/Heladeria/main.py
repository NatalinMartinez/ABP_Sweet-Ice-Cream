from data import Gestor

def main():
    gestor = Gestor()
    while True:
        print("\n------- Menú Principal -------")
        print("1. Gestionar Clientes")
        print("2. Gestionar Productos")
        print("3. Gestionar Ventas")
        print("4. Gestionar Pedidos")
        print("5. Salir")

        opcion = input(f"Seleccione una opción (1-5): ")
        if opcion == '1':
            gestor.menuClientes()
        elif opcion == '2':
            gestor.menuProductos()
        elif opcion == '3':
            gestor.menuVentas()
        elif opcion == '4':
            gestor.menuPedidos()
        elif opcion == '5':
            gestor.desconectar()
            break
        else:
            print(f"Opción no válida. Por favor, seleccione entre 1 - 5❗.")

if __name__ == "__main__":
    main()
