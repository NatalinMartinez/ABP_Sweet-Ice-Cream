# main.py
RED = '\033[31m'
GREEN = '\033[32m'
BLUE = '\033[34m'
RESET = '\033[0m'

from data import Gestor

def main():
    gestor = Gestor()
    while True:
        print("\n\tBienvenido a Nuestra Heladería Sweet Ice Cream🍦")
        print("\n-------Menú Principal-------:")
        print("1. Gestionar Clientes")
        print("2. Gestionar Productos")
        print("3. Gestionar Ventas")
        print("4. Gestionar Pedidos")
        print("5. Salir")

        opcion = input(f"{BLUE}Seleccione una opción (1-5): {RESET}")
        if opcion == '1':
            gestor.menuClientes()
        elif opcion == '2':
            gestor.menuProductos()
        elif opcion == '3':
            gestor.menuVentas()
        elif opcion == '4':
            gestor.menuPedidos()
        elif opcion == '5':
            print(f"{GREEN}¡Regresa pronto, gracias por preferirnos😊!{RESET}")
            break
        else:
            print(f"{RED}Opción no válida. Por favor, seleccione entre 1 - 5❗.{RESET}")

if __name__ == "__main__":
    main()
