import mysql.connector
from mysql.connector import Error
from decimal import Decimal

RED = '\033[31m'
GREEN = '\033[32m'
BLUE = '\033[34m'
RESET = '\033[0m'

class Cliente:
    def __init__(self, id_cliente, nombre, direccion, telefono):
        self.id_cliente = id_cliente
        self.nombre = nombre
        self.direccion = direccion
        self.telefono = telefono

    def __str__(self):
        return f"ID: {self.id_cliente}, Nombre: {self.nombre}, Dirección: {self.direccion}, Teléfono: {self.telefono}"

class Producto:
    def __init__(self, id_producto, nombre, precio):
        self.id_producto = id_producto
        self.nombre = nombre
        self.precio = Decimal(precio)  # Convertir a Decimal

    def __str__(self):
        return f"ID: {self.id_producto}, Nombre: {self.nombre}, Precio: {self.precio:.2f}"

class Venta:
    def __init__(self, cantidad, cliente, producto):
        self.cantidad = cantidad
        self.cliente = cliente
        self.producto = producto

    def totalPagar(self):
        subtotal = Decimal(self.cantidad) * self.producto.precio
        iva = subtotal * Decimal('0.12')
        return subtotal + iva

    def imprimirFactura(self):
        print("\n--- Factura de Venta ---")
        print(f"Cliente: {self.cliente.nombre}")
        print(f"Producto: {self.producto.nombre}")
        print(f"Cantidad: {self.cantidad}")
        subtotal = Decimal(self.cantidad) * self.producto.precio
        print(f"Subtotal: ${subtotal:.2f}")
        iva = subtotal * Decimal('0.12')
        print(f"IVA (12%): ${iva:.2f}")
        print(f"Total a Pagar: ${self.totalPagar():.2f}")
        print("-------------------------")

class Pedido:
    def __init__(self, id_pedido, cliente, productos, tipo_entrega):
        self.id_pedido = id_pedido
        self.cliente = cliente
        self.productos = productos
        self.tipo_entrega = tipo_entrega

    def __str__(self):
        productos_str = ', '.join([producto.nombre for producto in self.productos])
        return f"ID: {self.id_pedido}, Cliente: {self.cliente.nombre}, Productos: {productos_str}, Tipo de entrega: {self.tipo_entrega}"

    def imprimirFactura(self):
        print("\n--- Factura de Pedido ---")
        print(f"ID del Pedido: {self.id_pedido}")
        print(f"Cliente: {self.cliente.nombre}")
        print(f"Dirección: {self.cliente.direccion}")
        print(f"Teléfono: {self.cliente.telefono}")
        print(f"Tipo de Entrega: {self.tipo_entrega}")
        print("Productos:")
        total = Decimal('0')
        for producto in self.productos:
            print(f"  - {producto.nombre}: ${producto.precio:.2f}")
            total += producto.precio
        iva = total * Decimal('0.12')
        print(f"Subtotal: ${total:.2f}")
        print(f"IVA (12%): ${iva:.2f}")
        print(f"Total a Pagar: ${total + iva:.2f}")
        print("-------------------------")

class Gestor:
    def __init__(self):
        self.clientes = {}
        self.productos = {}
        self.ventas = []
        self.pedidos = []
        self.pedido_id = 1

        # Datos de conexión a MySQL
        self._host = "localhost"
        self._user = "root"
        self._password = ""
        self._database = "sweetIceCream"

        # Conectar a la base de datos
        self.conexion = self.conectar()

        self.productos_menu = [
            Producto(1, 'Menta', '1.50'),
            Producto(2, 'Frutilla', '1.50'),
            Producto(3, 'Vainilla', '1.50'),
            Producto(4, 'Chocolate', '1.50'),
            Producto(5, 'Oreo', '2.00'),
            Producto(6, 'Pistacho', '2.00'),
            Producto(7, 'Mora', '1.75'),
            Producto(8, 'Manicho', '2.00'),
            Producto(9, 'Napolitano', '1.75'),
            Producto(10, 'Chicle', '1.50'),
            Producto(11, 'M&M\'S', '2.50'),
            Producto(12, 'Maracuyá', '1.75')
        ]

        self.productos.update({str(p.id_producto): p for p in self.productos_menu})

    def conectar(self):
        try:
            connection = mysql.connector.connect(
                host=self._host,
                user=self._user,
                password=self._password,
                database=self._database
            )
            if connection.is_connected():
                print(f"{GREEN}Conexión a la base de datos exitosa.{RESET}")
                return connection
        except Error as e:
            print(f"{RED}Error al conectar a la base de datos: {e}{RESET}")
            return None

    def desconectar(self):
        if self.conexion.is_connected():
            self.conexion.close()
            print(f"{GREEN}Desconexión de la base de datos exitosa.{RESET}")

    def menuClientes(self):
        while True:
            print("\n------- Gestionar Clientes -------")
            print("1. Registrar Cliente")
            print("2. Leer Clientes")
            print("3. Volver al Menú Principal")

            opcion = input(f"{BLUE}Seleccione una opción (1-3): {RESET}")
            if opcion == '1':
                self.registrarCliente()
            elif opcion == '2':
                self.leerClientes()
            elif opcion == '3':
                break
            else:
                print(f"{RED}Opción no válida. Por favor, seleccione entre 1 - 3❗.{RESET}")

    def menuProductos(self):
        while True:
            print("\n------- Gestionar Productos -------")
            print("1. Ver menú de productos")
            print("2. Registrar Producto")
            print("3. Leer Productos")
            print("4. Volver al Menú Principal")

            opcion = input(f"{BLUE}Seleccione una opción (1-4): {RESET}")
            if opcion == '1':
                self.mostrarMenuProductos()
            elif opcion == '2':
                self.registrarProducto()
            elif opcion == '3':
                self.leerProductos()
            elif opcion == '4':
                break
            else:
                print(f"{RED}Opción no válida. Por favor, seleccione entre 1 - 4❗.{RESET}")

    def menuVentas(self):
        while True:
            print("\n------- Gestionar Ventas -------")
            print("1. Realizar Venta")
            print("2. Leer Ventas")
            print("3. Volver al Menú Principal")

            opcion = input(f"{BLUE}Seleccione una opción (1-3): {RESET}")
            if opcion == '1':
                self.realizarVenta()
            elif opcion == '2':
                self.leerVentas()
            elif opcion == '3':
                break
            else:
                print(f"{RED}Opción no válida. Por favor, seleccione entre 1 - 3❗.{RESET}")

    def menuPedidos(self):
        while True:
            print("\n------- Gestionar Pedidos -------")
            print("1. Agregar Pedido")
            print("2. Leer Pedidos")
            print("3. Volver al Menú Principal")

            opcion = input(f"{BLUE}Seleccione una opción (1-3): {RESET}")
            if opcion == '1':
                self.agregarPedido()
            elif opcion == '2':
                self.leerPedidos()
            elif opcion == '3':
                break
            else:
                print(f"{RED}Opción no válida. Por favor, seleccione entre 1 - 3❗.{RESET}")

    def registrarCliente(self):
        id_cliente = input("Ingrese ID del cliente: ")
        nombre = input("Ingrese nombre del cliente: ")
        direccion = input("Ingrese dirección del cliente: ")
        telefono = input("Ingrese teléfono del cliente: ")

        cliente = Cliente(id_cliente, nombre, direccion, telefono)
        self.clientes[id_cliente] = cliente
        print(f"{GREEN}Cliente registrado exitosamente.{RESET}")

    def leerClientes(self):
        print("\n--- Lista de Clientes ---")
        for cliente in self.clientes.values():
            print(cliente)

    def mostrarMenuProductos(self):
        print("\n--- Menú de Productos ---")
        for producto in self.productos_menu:
            print(producto)

    def registrarProducto(self):
        id_producto = input("Ingrese ID del producto: ")
        nombre = input("Ingrese nombre del producto: ")
        precio = input("Ingrese precio del producto: ")

        if id_producto in self.productos:
            print(f"{RED}El producto con este ID ya existe.{RESET}")
        else:
            producto = Producto(id_producto, nombre, precio)
            self.productos[id_producto] = producto
            print(f"{GREEN}Producto registrado exitosamente.{RESET}")

    def leerProductos(self):
        print("\n--- Lista de Productos ---")
        for producto in self.productos.values():
            print(producto)

    def realizarVenta(self):
        cliente_id = input("Ingrese ID del cliente: ")
        producto_id = input("Ingrese ID del producto: ")
        cantidad = int(input("Ingrese cantidad: "))

        cliente = self.clientes.get(cliente_id)
        producto = self.productos.get(producto_id)

        if cliente and producto:
            venta = Venta(cantidad, cliente, producto)
            venta.imprimirFactura()
            self.ventas.append(venta)
            print(f"{GREEN}Venta registrada exitosamente.{RESET}")
        else:
            print(f"{RED}Cliente o producto no encontrado.{RESET}")

    def leerVentas(self):
        print("\n--- Lista de Ventas ---")
        for venta in self.ventas:
            venta.imprimirFactura()

    def agregarPedido(self):
        cliente_id = input("Ingrese ID del cliente: ")
        tipo_entrega = input("Ingrese tipo de entrega (delivery/pickup): ")

        cliente = self.clientes.get(cliente_id)
        if not cliente:
            print(f"{RED}Cliente no encontrado.{RESET}")
            return

        productos = []
        while True:
            producto_id = input("Ingrese ID del producto (o 'fin' para terminar): ")
            if producto_id.lower() == 'fin':
                break
            producto = self.productos.get(producto_id)
            if producto:
                productos.append(producto)
            else:
                print(f"{RED}Producto no encontrado.{RESET}")

        if productos:
            pedido = Pedido(self.pedido_id, cliente, productos, tipo_entrega)
            self.pedidos.append(pedido)
            self.pedido_id += 1
            pedido.imprimirFactura()
            print(f"{GREEN}Pedido registrado exitosamente.{RESET}")
        else:
            print(f"{RED}No se ha agregado ningún producto al pedido.{RESET}")

    def leerPedidos(self):
        print("\n--- Lista de Pedidos ---")
        for pedido in self.pedidos:
            print(pedido)
